#include <stdlib.h>
#include <string.h>
#include "binarymath.h"



/**
 * Increment a BINARY_SIZE binary number expressed as a 
 * character string.
 * @param number The number we are passed
 * @returns Incremented version of the number
 */
char *inc(const char *number){
    char *result = (char*)malloc(BINARY_SIZE + 1);
    strncpy(result, number, BINARY_SIZE);
    result[BINARY_SIZE] = '\0';
    
    int i = BINARY_SIZE - 1;
    for (; i >= 0; i--){
      if(result[i] == '0'){
        result[i] = '1';
        return result;
      }
      else{ //if result[i] == 1
        result[i] = '0';
        if(result[i-1] == '1'){
          continue;
        }
        else{
          result[i-1] = '1';
          return result;
        }
      }
    }
    free(number);
    //result[0] = 'a';
    return result; 
}


/**
 * Negate a BINARY_SIZE binary number expressed as a character string
 * @param number The number we are passed
 * @returns Incremented version of the number
 */
char *negate(const char *number)
{
  char* result = (char*)malloc(BINARY_SIZE+1);
  strncpy(result, number, BINARY_SIZE);
  result[BINARY_SIZE] = '\0';
  int i = BINARY_SIZE-1;
  for(; i >= 0; i--){
    char b = result[i];
    char n = (b == '0') ? '1' : '0';
    result[i] = n;
  //result[1] = 'a';
  }
  /*
  int a = BINARY_SIZE - 1;
  for(; a >= 0; a--){
    if(result[a] == '0'){
      result[a] = '1';
      return result;
    }
    else{ //if result[a] == 1
        result[a] = '0';
        if(result[a-1] == '1'){
          continue;
        }
        else{
          result[a-1] = '1';
          return result;
        }
      }
    }
  */
  char* new_result = inc(result);
  free(number);
  free(result);
  return new_result;
}

/**
 * Add two BINARY_SIZE binary numbers expressed as
 * a character string. 
 * @param a First number to add
 * @param b Second number to add
 * @return a + b
 */
char *add(const char *a, const char *b)
{
  /*
   * Steps:
   * Make a copy of a and a copy of b
   * Make a result of all zeroes
   * if a[i] == 1, b[i] == 1, result[i] = 0 -> result[i] = 0, result[i-1] = 1
   * if a[i] == 1, b[i] == 1, result[i] = 1 -> result[i] = 1, result[i-1] = 1
   * if a[i] == 0, b[i] == 0, result[i] = 1 -> result[i] = 1, result[i-1] = 0
   * if a[i] == 0, b[i] == 0, result[i] = 0 -> resutl[i] = 0, result[i-1] = 0
   * if a[i] == 0, b[i] == 1, result
   */
  char* result = (char*)malloc(BINARY_SIZE + 1);
  //int i = BINARY_SIZE - 1;
  int i = 0;
  for(; i<BINARY_SIZE; i++){
    result[i] = '0';
  }
  i = BINARY_SIZE - 1;
  for(; i >= 0; i--){
    if(i == 0){
      if (a[i] == b[i]){
        return result;
      }
      else{
        if (result[i] == '1'){
          result[i] = '0';
        }
        else{
          result[i] = '1';
        }
        return result;
      }
    }
    if(a[i] == b[i]){
      //result[i] = '0';
      result[i-1] = a[i];
      continue;
    }
    else{
      if(result[i] == '0'){
        result[i] = '1';
        result[i-1] = '0';
      }
      else{
        result[i] = '0';
        result[i-1] = '1';
      }
    }
  }
  free(a);
  free(b); 
  return result;
}

/**
 * Subtract two BINARY_SIZE binary numbers expressed as
 * a character string.
 * @param a First number
 * @param b Second number 
 * @return a - b
 */
char *sub(const char *a, const char *b)
{
  char* result = (char*)malloc(BINARY_SIZE + 1);
  //strncpy(result, b, BINARY_SIZE);
  char* b_neg = (char*)malloc(BINARY_SIZE + 1);
  b_neg = negate(b);
  result = add(a,b_neg);
  result[BINARY_SIZE] = '\0';
  //result[1] = 'a';
  free(b_neg);
  free(a);
  free(b);
  return result;


}
