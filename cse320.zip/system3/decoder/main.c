//main.c
#include "stack.h"
#include "decoder.h"
#include <stdio.h>
#include <string.h>
char* xor(const char* encoded, const char* key);
char* rotate(const char*line, const int shift);
void initialize_list(LinkedList *list);
void append_list(LinkedList *list, const char *name);
void pop(LinkedList *list);
void free_list(LinkedList *list);
int main(int argc, char *argv[]){
  if (argc < 2){
    printf("Usage: decoder file\n");
    return 1;
  }
  FILE *fp = fopen(argv[1], "r");
  if (fp == NULL){
    printf("Unable to open input file\n");
    return 1;
  }
  char key[200];
  fgets(key, sizeof(key), fp);
  size_t len = strlen(key);
  if (key[len - 1] == '\n'){key[len-1] = '\0';}
  LinkedList Stack;
  initialize_list(&Stack);
  char buffer[200];
  int shift = 0;
  while(fgets(buffer, sizeof(buffer), fp) != NULL){
    char *result = xor(buffer, key);
    char *result_ = rotate(result, shift);
    shift++;
    append_list(&Stack, result_);
  }
  while(Stack.head != NULL){
    pop(&Stack);
  }
  free_list(&Stack);
  fclose(fp);
  return 0;
}
char* rotate(const char* line, const int shift){
  size_t len  = strlen(line) + 1;
  char *result = (char *)malloc(len);
  result[len-1] = '\0';
  
  //make the first half, shift to end
  //make second half, beginning to shift
  //concatenate the string to result
  char* first = (char*)malloc(len-shift-1);
  char* second= (char*)malloc(shift);
  
  int i  = 0;
  for (;i < shift+1;i++ ){
    second[i] = line[i];
  }
  int j = shift;
  int a = 0;
  for(;j<len-1; j++){
    first[a] = line[j];
    a++;
  }
  strncpy(result, first, len);
  strncat(result, second, len);//
  free(first);
  free(second);
  result[len-1] = '\0';
  return result;
}
char* xor(const char* encoded, const char* key){
  size_t len_key = strlen(key) + 1;
  char *result = (char *)malloc(len_key);
  result[len_key - 1] = '\0';
  int i = 0;
  int len = strlen(key);
  for (; i < len; i++){
    if (encoded[i] == key[i]){
      result[i] = ' ';
    }else{
      result[i] = 'X';
    }
  }
  return result;
}
/**
 *  * Initialize a linked list to empty
 *   * @param list Pointer to the linked list struct
 *    */
void initialize_list(LinkedList *list)
{
    list->head = NULL;
    list->tail = NULL;
}
/**
 *  * Append a name onto the end of the list.
 *   * @param list Pointer to the linked list struct
 *    * @param name Name to add to the list
 *     */
void append_list(LinkedList *list, const char *name)
{// Allocate a linked list node
    LinkedListNode *node = (LinkedListNode *)calloc(1, sizeof(LinkedListNode));
    node->next = NULL;      
    //Copy the name into the list
    node->name = (char *)calloc(strlen(name) + 1,
    sizeof(char));
    strncpy(node->name, name, strlen(name));
    
    if (list->tail == NULL){
    // List is empty, make this the head
    //and tail of the list
      list->head = node;
      list->tail = node;
    }else{//link onto the head of the list
      node->next = list->head;
      list->head = node;
    }
}
/**
 * Free the memory allocated for our list
 * @ param list Pointer to linked list object
 */
void free_list(LinkedList *list){
  LinkedListNode *node;
  for (node = list-> head; node != NULL;){
    LinkedListNode *next = node -> next;
    free(node -> name);
    free(node);
    node = next;
  }
  list->head = NULL;
  list->tail = NULL;
}
void pop(LinkedList *list){
  printf(list->head->name);
  printf("\n");
  free(head -> name);
  list->head = list->head->next;
}
