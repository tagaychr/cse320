//stack.c
#include "stack.h"

/**
 *  * Initialize a linked list to empty
 *   * @param list Pointer to the linked list struct
 *    */
void initialize_list(LinkedList *list)
{
    list->head = NULL;
    list->tail = NULL;
}
/**
 *  * Append a name onto the end of the list.
 *   * @param list Pointer to the linked list struct
 *    * @param name Name to add to the list
 *     */
void append_list(LinkedList *list, const char *name)
{// Allocate a linked list node
    LinkedListNode *node = (LinkedListNode *)calloc(1, sizeof(LinkedListNode));
    node->next = NULL;      
    //Copy the name into the list
    node->name = (char *)calloc(strlen(name) + 1,
    sizeof(char));
    strncpy(node->name, name, strlen(name));
    
    if (list->tail == NULL){
    // List is empty, make this the head
    //and tail of the list
      list->head = node;
      list->tail = node;
    }else{//link onto the tail of the list
      list->tail->next = node;
      list->tail = node;
    }
}
/**
 * Free the memory allocated for our list
 * @ param list Pointer to linked list object
 */
void free_list(LinkedList *list){
  LinkedListNode *node;
  for (node = list-> head; node != NULL;){
    LinkedListNode *next = node -> next;
    free(node -> name);
    free(node);
    node = next;
  }
  list->head = NULL;
  list->tail = NULL;
}
void pop(LinkedList *list){
  LinkedListNode *secondLast = (LinkedListNode *)calloc(1, sizeof(LinkedListNode));
  LinkedListNode last = list->head;
  while(last.next){
    secondLast = last;
    last = last->next;
  printf(tail->name);
  printf("\n");
  list->tail = secondLast;
  secondLast->next = NULL;

}

