//stack.h
#pragma once
#include <stdlib.h>  
#include <stdio.h>
#include <string.h>

/**
 *  * Actual nodes in our linked list
 *   */
typedef struct LinkedListNode
{
      char *name;
      struct LinkedListNode *next;

} LinkedListNode;

/**
 *  * A structure that represents our linked list
 *   */
typedef struct LinkedList
{
      LinkedListNode *head;
      LinkedListNode *tail;

} LinkedList;

//Forward References
void initialize_list(LinkedList *list);
void append_list(LinkedList *list, const char *name);
void free_list(LinkedList *list);
void pop(LinkedList *list);


