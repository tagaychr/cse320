#include "decoder.h"
#include <string.h>

/**
 * Decode an encoded string into a character stream.
 * @param encoded The input string we are decoding
 * @param decoded The output string we produce
 * @param maxLen The maximum size for decoded
 */
void addToIt(int *num)
{
    (*num)++;
}

void decoder(const char *encoded, char *decoded, int maxLen)
{
    // This is just a copy so it has something in decoded
  
  for (i = 0; i < maxLen; i++)
    {
      switch(encoded[i])
      {
        case 'x': decoded[i] = '0'; decoded[i+1]='0'; decoded[i+2]='0';
        case 'u': decoded[i] = '0'; decoded[i+1]='0'; decoded[i+2]='1';
        case 'a': decoded[i] = '0'; decoded[i+1]='1'; decoded[i+2]='0';
        case 'X': decoded[i] = '0'; decoded[i+1]='1'; decoded[i+2]='1';
        case 'F': decoded[i] = '1'; decoded[i+1]='0'; decoded[i+2]='0';
        case 'o': decoded[i] = '1'; decoded[i+1]='0'; decoded[i+2]='1';
        case '1': decoded[i] = '1'; decoded[i+1]='1'; decoded[i+2]='0';
        case 'E': decoded[i] = '1'; decoded[i+1]='1'; decoded[i+2]='1';
        case 'Q': decoded[i] = '0'; decoded[i+1]='0';
        case 'S': decoded[i] = '0'; decoded[i+1]='1';
        case 'y': decoded[i] = '1'; decoded[i+1]='0';
        case '5': decoded[i] = '1'; decoded[i+1]='1';
      }
    }
    strncpy(decoded, encoded, maxLen);

}

